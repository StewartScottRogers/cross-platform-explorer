# Sample Archive

This is a **real** multi-folder archive used to exercise the archive-preview pane
(inner-file drill-in, CPE-1360). It mirrors a tiny project layout:

- `docs/`   documentation (this file + `sub/notes.txt`)
- `images/` a logo PNG
- `data/`   a CSV table
- `src/`    a Python entry point
