"""Sample entry point packed inside the archive fixture."""


def greet(name: str) -> str:
    return f"Hello, {name}!"


def main() -> None:
    for who in ("world", "CPE"):
        print(greet(who))


if __name__ == "__main__":
    main()
